function changeText() {
    document.getElementById("message").innerText = "You clicked the button!";
}